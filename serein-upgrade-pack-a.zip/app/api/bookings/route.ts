import { NextResponse } from 'next/server'; import { prisma } from '@/lib/prisma';
export async function POST(req: Request) { const body = await req.json().catch(()=>null); if(!body) return NextResponse.json({error:'Invalid JSON'},{status:400});
const { intent, party, dateISO, arrivalMode, lighting, music, scent, stealth, notes, treatmentSlug } = body;
let treatment = null; if (treatmentSlug) { treatment = await prisma.treatment.findUnique({ where: { slug: treatmentSlug }}); }
const booking = await prisma.booking.create({ data: { intent, party, dateISO, arrivalMode, lighting, music, scent, stealth: !!stealth, notes: notes || '', treatmentId: treatment?.id } });
return NextResponse.json({ ok:true, id: booking.id }); }
