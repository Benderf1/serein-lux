import { NextResponse } from 'next/server'; import { prisma } from '@/lib/prisma';
export async function GET() { const bookings = await prisma.booking.findMany({ orderBy:{createdAt:'desc'}, include:{treatment:true} });
const safe = bookings.map(b => ({ id:b.id, createdAt:b.createdAt, status:b.status, intent:b.intent, party:b.party, dateISO:b.dateISO, arrivalMode:b.arrivalMode, lighting:b.lighting, music:b.music, scent:b.scent, stealth:b.stealth, treatmentName:b.treatment?.name ?? null }));
return NextResponse.json({ items: safe }); }
