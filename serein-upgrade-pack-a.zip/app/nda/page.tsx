'use client'; import { useState } from 'react';
export default function NDA(){ const [agreed,setAgreed]=useState(false); const [signed,setSigned]=useState(false);
return (<section className="mt-6"><h2 className="text-2xl">NDA — House of Serein</h2><div className="rounded-2xl border border-black/10 mt-4 p-5 bg-bone">
<p className="text-sm opacity-80">Placeholder NDA. In production, this becomes a PDF e-sign flow.</p>
<div className="mt-4 h-48 rounded-xl bg-sand p-4 text-xs opacity-80 overflow-auto"><p><strong>Confidentiality Agreement (Preview)</strong></p><p>All information shared during your visit is confidential...</p></div>
<div className="mt-4 flex items-center gap-2"><input id="agree" type="checkbox" checked={agreed} onChange={e=>setAgreed(e.target.checked)} /><label htmlFor="agree" className="text-sm opacity-80">I agree to the NDA terms.</label></div>
<button disabled={!agreed} onClick={()=>setSigned(true)} className="mt-4 px-4 py-2 rounded-2xl bg-ink text-bone disabled:opacity-40">Sign</button>
{signed && <p className="text-sm mt-3">Signed. A downloadable copy will appear here in production.</p>}</div></section>);}
