'use client'; import { useEffect, useState } from 'react';
type Item={id:string;createdAt:string;status:string;intent:string|null;party:string|null;dateISO:string|null;arrivalMode:string|null;lighting:number;music:number;scent:string;stealth:boolean;treatmentName:string|null;};
export default function Queue(){ const [items,setItems]=useState<Item[]>([]); const [loading,setLoading]=useState(true);
useEffect(()=>{ fetch('/api/bookings/list').then(r=>r.json()).then(d=>{ setItems(d.items); setLoading(false); }); },[]);
return (<section className="mt-6"><h2 className="text-2xl">Backoffice — Queue</h2><p className="opacity-70 text-sm mt-1">Aliases by default. Legal names hidden. Stealth bookings marked with 🕶️.</p>
<div className="mt-4 rounded-2xl border border-black/10 p-4 bg-bone">{loading? <div className="opacity-60 text-sm">Loading…</div> :
<ul className="space-y-3">{items.map(b=>(<li key={b.id} className="rounded-xl border border-black/10 p-4"><div className="flex justify-between items-center">
<div className="text-sm opacity-70">{new Date(b.createdAt).toLocaleString()}</div>{b.stealth && <div title="Stealth mode" className="text-sm">🕶️</div>}</div>
<div className="mt-2 text-sm"><div>Status: {b.status}</div><div>Intent: {b.intent ?? '—'} · Party: {b.party ?? '—'} · Date: {b.dateISO ?? '—'} · Arrival: {b.arrivalMode ?? '—'}</div>
<div>Treatment: {b.treatmentName ?? '—'}</div><div>Prefs: Lighting {b.lighting}% · Music {b.music}% · Scent {b.scent}</div></div></li>))}</ul>}</div></section>);}
