'use client';
import { useState } from 'react';
import { create } from 'zustand';

type Booking = {
  intent: 'Unwind'|'Performance'|'Reset'|null;
  party: 'Solo'|'Couple'|'House'|null;
  date: string;
  arrival: 'Front'|'Discreet'|'Back-of-house'|null;
  lighting: number;
  music: number;
  scent: 'None'|'Light'|'Herbal'|'Floral';
}

const useStore = create<{
  step: number;
  booking: Booking;
  next: ()=>void; prev: ()=>void; update: (p: Partial<Booking>)=>void;
}>(set => ({
  step: 1,
  booking: { intent: null, party: null, date: '', arrival: null, lighting: 40, music: 20, scent: 'None' },
  next: ()=>set(s=>({step: Math.min(5, s.step+1)})),
  prev: ()=>set(s=>({step: Math.max(1, s.step-1)})),
  update: (p)=>set(s=>({booking: {...s.booking, ...p}})),
}));

export default function Book() {
  const { step, next, prev, booking, update } = useStore();

  return (
    <section className="mt-6">
      <h2 className="text-2xl">Book — Private Arrival</h2>
      <div className="rounded-2xl border border-black/10 mt-4 p-5 bg-bone">
        {step===1 && <Step1 value={booking.intent} onChange={(v)=>update({intent:v as any})} />}
        {step===2 && <Step2 value={booking.party} onChange={(v)=>update({party:v as any})} />}
        {step===3 && <Step3 value={{date:booking.date, arrival:booking.arrival}} onChange={(p)=>update(p)} />}
        {step===4 && <Step4 booking={booking} onChange={(p)=>update(p)} />}
        {step===5 && <Step5 booking={booking} />}
        <div className="mt-6 flex justify-between">
          <button onClick={prev} className="px-4 py-2 rounded-2xl border border-black/10">Back</button>
          <button onClick={next} className="px-4 py-2 rounded-2xl bg-ink text-bone">{step===5?'Confirm':'Next'}</button>
        </div>
      </div>
    </section>
  );
}

function Chip({active, children, onClick}:{active?:boolean, children:any, onClick?:()=>void}){
  return <button onClick={onClick} className={`px-4 py-2 rounded-2xl border ${active?'bg-ink text-bone border-ink':'border-black/10'} `}>{children}</button>
}

function Step1({value,onChange}:{value:Booking['intent'], onChange:(v:string)=>void}){
  const items = ['Unwind','Performance','Reset'];
  return (<div>
    <h3 className="text-lg">Step 1 · Intent</h3>
    <div className="mt-4 flex gap-3">{items.map(x=>(
      <Chip key={x} active={value===x} onClick={()=>onChange(x)}>{x}</Chip>
    ))}</div>
  </div>);
}

function Step2({value,onChange}:{value:Booking['party'], onChange:(v:string)=>void}){
  const items = ['Solo','Couple','House'];
  return (<div>
    <h3 className="text-lg">Step 2 · Party</h3>
    <div className="mt-4 flex gap-3">{items.map(x=>(
      <Chip key={x} active={value===x} onClick={()=>onChange(x)}>{x}</Chip>
    ))}</div>
  </div>);
}

function Step3({value,onChange}:{value:{date:string, arrival:Booking['arrival']}, onChange:(p:any)=>void}){
  return (<div>
    <h3 className="text-lg">Step 3 · When & Arrival</h3>
    <div className="mt-4 flex flex-col gap-4">
      <input type="date" className="px-3 py-2 rounded-2xl border border-black/10 bg-white/70 w-60"
        value={value.date} onChange={e=>onChange({date:e.target.value})} />
      <div className="flex gap-3">
        {['Front','Discreet','Back-of-house'].map(x=>(
          <Chip key={x} active={value.arrival===x} onClick={()=>onChange({arrival:x})}>{x}</Chip>
        ))}
      </div>
    </div>
  </div>);
}

function Step4({booking,onChange}:{booking:Booking, onChange:(p:Partial<Booking>)=>void}){
  return (<div>
    <h3 className="text-lg">Step 4 · Preferences</h3>
    <div className="mt-4 grid gap-4 sm:grid-cols-2">
      <div>
        <label className="text-sm opacity-70">Lighting · {booking.lighting}%</label>
        <input type="range" min={0} max={100} value={booking.lighting} onChange={e=>onChange({lighting:Number(e.target.value)})} className="w-full" />
      </div>
      <div>
        <label className="text-sm opacity-70">Music · {booking.music}%</label>
        <input type="range" min={0} max={100} value={booking.music} onChange={e=>onChange({music:Number(e.target.value)})} className="w-full" />
      </div>
      <div>
        <label className="text-sm opacity-70">Scent</label>
        <select value={booking.scent} onChange={e=>onChange({scent:e.target.value as any})} className="px-3 py-2 rounded-2xl border border-black/10 bg-white/70">
          {['None','Light','Herbal','Floral'].map(x=>(<option key={x} value={x}>{x}</option>))}
        </select>
      </div>
    </div>
  </div>);
}

function Step5({booking}:{booking:Booking}){
  return (<div>
    <h3 className="text-lg">Step 5 · Summary</h3>
    <div className="mt-4 text-sm opacity-80 space-y-1">
      <div>Intent: {booking.intent||'—'}</div>
      <div>Party: {booking.party||'—'}</div>
      <div>Date: {booking.date||'—'}</div>
      <div>Arrival: {booking.arrival||'—'}</div>
      <div>Lighting: {booking.lighting}% · Music: {booking.music}% · Scent: {booking.scent}</div>
    </div>
    <p className="text-xs opacity-60 mt-4">On confirm, we’ll route to concierge for final human confirmation. (Stubbed)</p>
  </div>);
}
