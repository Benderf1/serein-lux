'use client';
import { useState } from 'react';

export default function Concierge() {
  const [msgs, setMsgs] = useState([{ you:false, text: 'Welcome. A human concierge will reply shortly.' }]);
  const [input, setInput] = useState('');
  return (
    <section className="mt-6">
      <h2 className="text-2xl">Concierge</h2>
      <div className="rounded-2xl border border-black/10 mt-4 p-4 bg-bone">
        <div className="min-h-56 max-h-96 overflow-auto space-y-3">
          {msgs.map((m, i) => (
            <div key={i} className={`text-sm ${m.you ? 'text-right' : ''}`}>
              <span className={`inline-block px-3 py-2 rounded-2xl ${m.you ? 'bg-ink text-bone' : 'bg-sand'}`}>{m.text}</span>
            </div>
          ))}
        </div>
        <form className="mt-4 flex gap-2" onSubmit={(e)=>{e.preventDefault(); if(!input.trim()) return; setMsgs([...msgs,{you:true,text:input}]); setInput('');}}>
          <input
            className="flex-1 px-3 py-2 rounded-2xl border border-black/10 bg-white/70"
            placeholder="Type briefly. Ephemeral by default."
            value={input}
            onChange={e=>setInput(e.target.value)}
          />
          <button className="px-4 py-2 rounded-2xl bg-ink text-bone">Send</button>
        </form>
      </div>
      <p className="text-xs opacity-60 mt-2">Threads auto-purge after 24h in Stealth mode.</p>
    </section>
  );
}
