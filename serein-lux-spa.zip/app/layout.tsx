import './globals.css';
import { ReactNode } from 'react';
import Link from 'next/link';

export const metadata = {
  title: 'Serein — Quiet Spa',
  description: 'Time, held still.',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen antialiased">
        <header className="px-6 py-4">
          <nav className="max-w-5xl mx-auto flex items-center justify-between">
            <Link href="/" className="text-sm tracking-wide opacity-80 hover:opacity-100 transition">SEREIN</Link>
            <div className="flex items-center gap-6 text-sm">
              <Link href="/treatments" className="opacity-80 hover:opacity-100">Treatments</Link>
              <Link href="/book" className="opacity-80 hover:opacity-100">Book</Link>
              <Link href="/concierge" className="opacity-80 hover:opacity-100">Concierge</Link>
            </div>
          </nav>
        </header>
        <main className="max-w-5xl mx-auto px-6 pb-24">{children}</main>
        <footer className="border-t border-black/10 mt-24">
          <div className="max-w-5xl mx-auto px-6 py-8 text-xs opacity-60">
            © {new Date().getFullYear()} Serein. Privacy by default.
          </div>
        </footer>
      </body>
    </html>
  )
}
