const treatments = [
  { id: 'reset', name: 'Reset', duration: 90, intensity: 'Low', blurb: 'Thermal cycle + long fascia work.' },
  { id: 'performance', name: 'Performance', duration: 75, intensity: 'Medium', blurb: 'Contrast therapy and deep tissue.' },
  { id: 'unwind', name: 'Unwind', duration: 60, intensity: 'Low', blurb: 'Stillness, warmth, and breath.' },
];

export default function Treatments() {
  return (
    <section className="mt-6">
      <h2 className="text-2xl">Treatments</h2>
      <p className="opacity-75 mt-2">What do you need today?</p>
      <div className="grid sm:grid-cols-2 gap-6 mt-6">
        {treatments.map(t => (
          <div key={t.id} className="rounded-2xl border border-black/10 p-5 shadow-quiet bg-bone">
            <div className="h-32 rounded-xl bg-sand mb-4" />
            <div className="flex items-center justify-between">
              <h3 className="text-lg">{t.name}</h3>
              <span className="text-xs opacity-70">{t.duration} min · {t.intensity}</span>
            </div>
            <p className="text-sm opacity-80 mt-2">{t.blurb}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
