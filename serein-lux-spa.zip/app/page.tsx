import Link from 'next/link';

export default function Page() {
  return (
    <section className="mt-10">
      <div className="rounded-2xl overflow-hidden shadow-quiet border border-black/10">
        <div className="h-64 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-linen to-bone" />
      </div>
      <h1 className="text-4xl md:text-5xl tracking-tight mt-8">Time, held still.</h1>
      <p className="mt-3 max-w-2xl opacity-80">
        A private house of heat, stone, and silence. Book discreetly. Arrive quietly.
      </p>
      <div className="mt-8 flex gap-3">
        <Link href="/book" className="px-5 py-2.5 rounded-2xl bg-ink text-bone">Book time</Link>
        <Link href="/concierge" className="px-5 py-2.5 rounded-2xl border border-black/10">Concierge</Link>
      </div>
    </section>
  );
}
