# Serein — Quiet Luxury Spa (Replit-ready)

Minimal, production-leaning starter for an ultra-discreet spa app. Next.js 14 + Tailwind. 
Auth, DB, and staff tools are stubbed to keep this runnable in Replit instantly.

## Install / Run
1) In Replit: Create a Node.js repl, upload this folder (or import the zip).
2) In the shell: `npm install`
3) Dev server: `npm run dev` (Replit will expose the webview on port 3000).

## What’s included
- App Router pages: Home, Treatments, Booking Wizard, Concierge placeholder
- Quiet-luxury tokens (bone/sand/oat/peat/ink/sage), generous spacing, soft borders
- Motion kept minimal; no 3rd‑party analytics, no fonts by default (system stack)

## Next steps (optional)
- Add Passkey + magic-link auth (NextAuth or Lucia) 
- Add Prisma + SQLite (for Replit) or Postgres (for Vercel) for bookings/members
- Build Staff Queue and NDA signer pages
- Wire Concierge to a human dashboard; keep messages ephemeral by default
