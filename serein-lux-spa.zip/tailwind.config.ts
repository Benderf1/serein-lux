import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        sand: '#E8E3DA',
        bone: '#F5F3EF',
        linen: '#EDE7E1',
        oat: '#D8CEC0',
        peat: '#5E574E',
        ink: '#111111',
        sage: '#9BA393',
      },
      borderRadius: {
        '2xl': '1rem',
      },
      boxShadow: {
        'quiet': '0 1px 2px rgba(0,0,0,0.04)',
      }
    },
  },
  plugins: [],
};
export default config;
